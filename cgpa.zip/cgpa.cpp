#include <iostream>
#include <vector>
#include <limits>

using namespace std;

class Subject {
public:
    string subjectname;
    int credit;
    float gradepoint;

    Subject(string name, int cr, float gp)
        : subjectname(name), credit(cr), gradepoint(gp) {}
};

class Student {
public:
    string name;
    vector<Subject> subjects;

    Student(string studentName) : name(studentName) {}

    void addSubject(const string& subjectName, int credit, float gradepoint) {
        subjects.emplace_back(subjectName, credit, gradepoint);
    }

    float calculateCGPA() const {
        int totalCredit = 0;
        float weightedGradePoints = 0.0f;

        for (const Subject& subject : subjects) {
            totalCredit += subject.credit;
            weightedGradePoints += subject.credit * subject.gradepoint;
        }

        return (totalCredit > 0) ? (weightedGradePoints / totalCredit) : 0.0f;
    }

    void displayCGPA() const {
        cout << "Student name: " << name << endl;
        float cgpa = calculateCGPA();
        cout << "CGPA: " << cgpa << endl;
    }
};

int main() {
    string studentName;
    cout << "Enter student's name: ";
    getline(cin, studentName);

    int numSub = 0;
    cout << "Enter the number of subjects: ";
    if (!(cin >> numSub)) {
        cerr << "Invalid number of subjects." << endl;
        return 1;
    }

    // consume the trailing newline so getline works below
    cin.ignore(numeric_limits<streamsize>::max(), '\n');

    Student student(studentName);

    for (int i = 0; i < numSub; i++) {
        string subjectName;
        int credit = 0;
        float gradepoint = 0.0f;

        cout << "Enter the subject's name: ";
        getline(cin, subjectName);

        cout << "Enter the credit: ";
        while (!(cin >> credit)) {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Please enter a valid integer for credit: ";
        }

        cout << "Enter the gradepoints for " << subjectName << ": ";
        while (!(cin >> gradepoint)) {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Please enter a valid number for gradepoints: ";
        }

        // consume newline before next getline
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        student.addSubject(subjectName, credit, gradepoint);
    }

    student.displayCGPA();
    return 0;
}
